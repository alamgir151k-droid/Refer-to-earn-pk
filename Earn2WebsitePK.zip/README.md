# Earn2WebsitePK 💰

Referral-based earning website demo.

## Features
- User signup/login
- Referral system (+10 balance per referral)
- User dashboard
- Admin panel

## Installation
1. Clone repo:
   ```
   git clone https://github.com/your-username/Earn2WebsitePK.git
   cd Earn2WebsitePK
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run app:
   ```
   python app.py
   ```

4. Open in browser:
   ```
   http://127.0.0.1:5000
   ```

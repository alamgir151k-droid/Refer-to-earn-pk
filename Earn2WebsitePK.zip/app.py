from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import uuid

app = Flask(__name__)
app.secret_key = "supersecret"

# Initialize DB
def init_db():
    con = sqlite3.connect("site.db")
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        referral_code TEXT,
        referred_by TEXT,
        balance INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0
    )""")
    con.commit()
    con.close()

init_db()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        referred_by = request.args.get("ref", None)

        referral_code = str(uuid.uuid4())[:8]

        con = sqlite3.connect("site.db")
        cur = con.cursor()
        try:
            cur.execute("INSERT INTO users (username,password,referral_code,referred_by) VALUES (?,?,?,?)",
                        (username,password,referral_code,referred_by))
            con.commit()
        except:
            return "Username already exists!"
        con.close()

        if referred_by:
            con = sqlite3.connect("site.db")
            cur = con.cursor()
            cur.execute("UPDATE users SET balance = balance + 10 WHERE referral_code=?", (referred_by,))
            con.commit()
            con.close()

        return redirect(url_for("login"))
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        con = sqlite3.connect("site.db")
        cur = con.cursor()
        cur.execute("SELECT * FROM users WHERE username=? AND password=?", (username,password))
        user = cur.fetchone()
        con.close()

        if user:
            session["user"] = user[1]
            session["is_admin"] = user[6]
            return redirect(url_for("dashboard"))
        else:
            return "Invalid credentials"
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    con = sqlite3.connect("site.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM users WHERE username=?", (session["user"],))
    user = cur.fetchone()
    con.close()

    referral_link = request.host_url + "signup?ref=" + user[3]
    return render_template("dashboard.html", user=user, referral_link=referral_link)

@app.route("/admin")
def admin():
    if "user" not in session or session["is_admin"] == 0:
        return "Not Authorized!"

    con = sqlite3.connect("site.db")
    cur = con.cursor()
    cur.execute("SELECT username,balance,referral_code,referred_by FROM users")
    all_users = cur.fetchall()
    con.close()
    return render_template("admin.html", users=all_users)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
